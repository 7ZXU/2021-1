package com.example.week14_2017310683

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
