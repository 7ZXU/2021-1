package com.example.w12_2017310683;

import io.flutter.embedding.android.FlutterActivity;

public class MainActivity extends FlutterActivity {
}
